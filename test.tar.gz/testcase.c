/**************************************************************************************************/
/* Copyright (C) Sun Zenan, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  testcase.c                                                           */
/*  PRINCIPAL AUTHOR      :  SunZenan                                                             */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  any                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/26                                                           */
/*  DESCRIPTION           :  It is a module test program                                          */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Sun Zenan, 2014/09/29
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.h"

int results[13] = {1,1,1,1,1,1,1,1,1,1,1,1,1};
char err_info[13][100] =
{
    {"TC1: Initialize the menu linktable."},
    {"TC1.1: Start the menu."},
    {"TC2.1: Add command to a linktable that not exist."},
    {"TC2.2: Add command to an exist linktable."},
    {"TC3.1: Delete command from an empty linktable."},
    {"TC3.2: Delete the command that not available from an empty linktable."},
    {"TC3.3: Delete the command that not available from an exist linktable."},
    {"TC3.4: Delete the command from an exist linktable."},
    {"TC4.1: Show a not exist linktable."},
    {"TC4.2: Show a exist linktable."},
    {"TC5.1: Find the command that not available from an empty linktable."},
    {"TC5.2: Find the command from an exist linktable."},
    {"TC5.3: Find the command that not available from an exist linktable."}
};

int main()
{  
    /*test InitMenu fuction*/
    tLinkTable *p = InitMenu();
    if(p == NULL)
    {   
        printf("TC1 success\n");
    }
    else printf("TC1 fail\n");
    /*test MenuStart function*/
    int mstrt=MenuStart();
    if(mstrt==SUCCESS)
    {
        printf("TC1.1 success\n");
        results[1]=0;    
    }
    else 
    {
        printf("TC1.1 fail\n");
    }
    /*test add command to empty table*/
    int addcmdret = AddCmd(p);
    if(addcmdret == SUCCESS)
    {
        printf("TC2.1 success\n");
        results[2] = 0;       
    }
    else printf("TC2.1 fail\n");    
    tLinkTable *head= (tLinkTable *)malloc(sizeof(tLinkTable));
    /*test add command to exist table*/
    int addcmdret1 = AddCmd(head);
    if(addcmdret1 == SUCCESS)
    {
        printf("TC2.2 success\n");
        results[3] = 0;       
    }
    else printf("TC2.2 fail\n");
    char cmd[MAX_LENTH]="command";
    /*test delete command from empty table*/
    int delcmdret = DelCmd(p,cmd);
    if(delcmdret == SUCCESS)
    {
        printf("TC3.1 success\n");
        results[4] = 0;       
    }
    else printf("TC3.1 fail\n");
    /*test delete command not available from empty table*/
    int delcmdret1 = DelCmd(p,NULL);
    if(delcmdret1 == SUCCESS)
    { 
        printf("TC3.2 success\n");
        results[5] = 0;       
    }
    else printf("TC3.2 fail\n");
    /*test delete command not available from exist table*/
    int delcmdret2 = DelCmd(head,NULL);
    if(delcmdret2 == SUCCESS)
    {
        printf("TC3.3 success\n");
        results[6] = 0;       
    } 
    else printf("TC3.3 fail\n");
    /*test delete command from exist table*/
    int delcmdret3 = DelCmd(head,cmd);
    if(delcmdret3 == SUCCESS)
    {
        printf("TC3.4 success\n");
        results[7] = 0;       
    }
    else printf("TC3.4 fail");
    /*test show a not exist linktable*/
    int shwlstret1 = showlist(p);
    if(shwlstret1 == SUCCESS)
    {
        printf("TC4.1 success\n");
        results[8] = 0;
    }
    else printf("TC4.1 fail\n");
    /*test show an exist linktable*/
    int shwlstret2 =showlist(head);
    if(shwlstret2 == SUCCESS)
    {
        printf("TC4.2 success\n");
        results[9] = 0;
    }
    else printf("TC4.2 fail\n");
    /*test find command not available from empty table*/
    tDNode* fndcmdret1 = Find(p,NULL);
    if(fndcmdret1 != NULL)
    {
        printf("TC5.1 success\n");
        results[10] = 0;
    }
    else printf("TC5.1 fail\n");
    /*test find command from an exist table*/
    tDNode* fndcmdret2 = Find(head,cmd);
    if(fndcmdret2 != NULL)
    {
        printf("TC5.2 success\n");
        results[11] = 0;
    }
    else printf("TC5.2 fail\n");
    /*test find command not available from an exist table*/
    tDNode* fndcmdret3 = Find(head,NULL);
    if(fndcmdret3 != NULL)
    {
        printf("TC5.3 success\n");
        results[12] = 0;
    }
    else printf("TC5.3 fail\n");
    /* test report */
    printf("Test report:\n");
    int i;
    for(i=0;i<=13;i++)
    {
        if(results[i] == 1)
        {
            printf("TestCase No.%dFailure - %s\n",i,err_info[i]);
        }
    }
}
