This is the ftpmenu program
    
Build procedure    
    $ gcc -o main ftp_menu.c linktable.c test.c
    $ ./main 
    # you can input 1 or 2 to choose add command or delete command.
    
    
