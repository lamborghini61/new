This is the test program
    
Build procedure    
    $ gcc -o main ftp_menu.c linktable.c test.c
    $ ./maini 
    # you can input 1 or 2 to choose add command or delete command.
    
    
