This is the test program
    Build procedure    
    $ gcc -o main ftp_menu.c linktable.c test.c
    $ ./main
    #please enter 1(add command) or 2(delete)to choose:
        1
        please enter the command:
        please enter the description:
        2  
        please enter the command you want to delete:
        command has  not been found.
        command has been deleted. 
    
    
