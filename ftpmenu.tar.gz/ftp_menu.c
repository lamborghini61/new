/**************************************************************************************************/
/* Copyright (C) Sun Zenan, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  ftp_menu.c                                                           */
/*  PRINCIPAL AUTHOR      :  SunZenan                                                             */
/*  SUBSYSTEM NAME        :  ftp_menu                                                             */
/*  MODULE NAME           :  ftp_menu                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  any                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/19                                                           */
/*  DESCRIPTION           :  It is a ftpmenu program                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Sun Zenan, 2014/09/21
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"linktable.h"
#include"ftp_menu.h"

int showlist(tLinkTable* head)
{   
    tDNode *p = (tDNode*)GetLinkTableHead(head);
    while(p!=NULL)
    {
        printf("%s - %s\n",p->cmd,p->dsc);
        p = (tDNode*)GetNextLinkTableNode(head,(tLinkTableNode *)p);
    }
    return 0;
}

tDNode* Find(tLinkTable *head, char *cmd)
{
    tDNode * p = (tDNode*)GetLinkTableHead(head);
    while(p!=NULL)
    {
        if(!strcmp(p->cmd,cmd))
        {
            return p;
        }
        p = (tDNode*)GetNextLinkTableNode(head,(tLinkTableNode *)p);
    }
    return NULL;
}


static tDNode menulist[]=
{     
    {NULL,"help","it is the menulist:\n"},
    {NULL,"version","it is the first version\n"},
    {NULL,"send","it is the send cmd\n"},
    {NULL,"recv","it is the recv cmd\n"}

};

tLinkTable* Init() 
{   
    tLinkTable *head=NULL;
    head = CreateLinkTable();
    AddLinkTableNode(head,(tLinkTableNode*) &menulist[0]);
    AddLinkTableNode(head,(tLinkTableNode*) &menulist[1]);
    AddLinkTableNode(head,(tLinkTableNode*) &menulist[2]);
    AddLinkTableNode(head,(tLinkTableNode*) &menulist[3]);     
    return head;
}

int AddCmd(tLinkTable* head)
{
   if(head==NULL)
   {
       return -1;
   }
   tDNode* p= (tDNode*)malloc(sizeof(tDNode));
   char  command[MAX_LENTH];
   printf("please enter command:\n");
   scanf("%s",command);
   p->cmd=command;
   char  descrp[MAX_LENTH];
   printf("please enter description:\n");
   scanf("%s",descrp);
   p->dsc=descrp;
   AddLinkTableNode(head,(tLinkTableNode*)p);
   return 0;
}

int DelCmd(tLinkTable *head, char *cmd)
{
    tDNode* tmp=Find(head,cmd);
    if(tmp==NULL)
    {
        printf("cmd has not been found\n");
        return -1;
    }
    DelLinkTableNode(head,(tLinkTableNode*)tmp); 
    printf("cmd has been deleted\n");   
    showlist(head);
    return 0;
}

