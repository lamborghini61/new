/**************************************************************************************************/
/* Copyright (C) Sun Zenan, SSE@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  SunZenan                                                             */
/*  SUBSYSTEM NAME        :  ftp_menu                                                             */
/*  MODULE NAME           :  ftp_menu                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  any                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  It is a test ft_menu program                                         */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Sun Zenan, 2014/09/22
 *
 */

#include"ftp_menu.h"
#include<stdio.h>
#include<stdlib.h>
#include"linktable.h"

main()
{  
    tLinkTable *p;
    p=Init();
    while(1)
    {
        int a;
        printf("please choose 1(add command) or 2(delete command):\n");
        scanf("%d",&a);
        if(a==1)
        {
            char delc[MAX_LENTH];
            printf("enter cmd you want to delete:\n");
            scanf("%s",delc);
            DelCmd(p,delc);
        }
        else if (a==2)
        {   
            AddCmd(p);
            showlist(p);
        }
        else
        {
            printf("you are enter a wrong number!");             
        }
     }    
}
